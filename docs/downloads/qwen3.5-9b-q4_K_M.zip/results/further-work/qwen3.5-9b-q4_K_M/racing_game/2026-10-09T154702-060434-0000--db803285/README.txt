FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3.5-9b-q4_K_M--56671c2ab938\02_racing_game\2026-10-09T154702-060434+0000--db803285
