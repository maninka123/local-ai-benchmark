# CASE_03: Missing Laboratory Prototype
## Investigation Report

---

## 1. Executive Summary

This investigation examines the disappearance of a laboratory prototype between 18:00 and 18:18 on the date of incident. The prototype was last confirmed visible in the Lab at 18:00 (V02) and discovered missing by 18:18 (V05).

**Key Findings:**
- The Service Corridor provides an unmonitored access route to the Lab (V01, V10)
- Two individuals entered via the Service Door at 18:14 per access log (D01)
- Eli Stone had documented motive for needing the prototype (D03)
- Maya Reed was carrying a cardboard box that could have transported the prototype (V08, D02)
- Visual identification from camera footage is unreliable due to rendering limitations

**Conclusion:** The prototype was removed through the unmonitored Service Corridor. While Eli Stone and Maya Reed entered together at 18:14, definitive attribution of responsibility cannot be made with current evidence. Confidence level: 65%.

---

## 2. Evidence Inventory

### Visual Exhibits (V01-V10)
| ID | Type | Timestamp | Description |
|----|------|-----------|-------------|
| V01 | Floor Plan | N/A | Facility layout showing Lab, East Corridor, Service Corridor (unmonitored link), Cafeteria, East Exit |
| V02 | Camera Footage | 18:00 | Lab camera - prototype visible on table |
| V03 | Camera Footage | 18:10 | East Corridor - Nora Vale (teal coat) present |
| V04 | Camera Footage | 18:14 | Service Door - two figures entering, grey rendering |
| V05 | Camera Footage | 18:18 | Lab camera - prototype missing from table |
| V06 | Camera Footage | 18:12 | Cafeteria - Theo Park (blue coat) present |
| V07 | Camera Footage | 18:13 | Reception - Ada Finch (red coat) present |
| V08 | Camera Footage | 18:11 | Loading Bay - Maya Reed (purple coat) with cardboard box |
| V09 | Object Detail | N/A | Reference image of prototype on table |
| V10 | Camera Status | N/A | Service camera shows "BLIND SPOT" designation |

### Documentary Evidence (D01-D03)
| ID | Type | Content |
|----|------|---------|
| D01 | Access Log | Badge credential records for facility entry 18:10-18:14 |
| D02 | Witness Statements | Unverified statements from five staff members |
| D03 | Internal Messages | Communications establishing motive and operational context |

---

## 3. Timeline

| Time | Event | Source | Type |
|------|-------|--------|------|
| 17:00 | Eli Stone message: "My project needs that prototype tomorrow" | D03 | Statement |
| 17:10 | Maya Reed message: "Please move the cardboard consumables box to the loading bay" | D03 | Statement |
| 17:20 | Security note: Coat descriptions from shift assignments; Service corridor is camera blind spot | D03 | Note |
| 18:00 | Prototype visible in Lab on table | V02 | Direct Observation |
| 18:10 | Nora Vale (teal coat) seen in East Corridor | V03 | Direct Observation |
| 18:11 | Maya Reed (purple coat) in Loading Bay with cardboard box | V08 | Direct Observation |
| 18:12 | Theo Park (blue coat) in Cafeteria | V06 | Direct Observation |
| 18:13 | Ada Finch (red coat) at Reception | V07 | Direct Observation |
| 18:14 | Two figures enter through Service Door | V04 | Direct Observation |
| 18:14 | Access log: Eli Stone and Maya Reed entered via SERVICE_DOOR | D01 | Recorded Event |
| 18:18 | Prototype missing from Lab | V05 | Direct Observation |

**Gaps:**
- No direct visual evidence of who entered the Lab after 18:14
- No timestamp showing when prototype was removed from Lab
- Coat color discrepancy between expected (Eli=orange, Maya=purple) and observed (both grey in V04)

---

## 4. Suspect Analysis

### Eli Stone
| Factor | Assessment |
|--------|------------|
| **Motive** | HIGH - Message at 17:00 states "My project needs that prototype tomorrow" |
| **Opportunity** | HIGH - Entered via Service Door at 18:14 (D01) |
| **Alibi** | WEAK - Claims he did not approach lab after 18:00 (D02), but access log shows entry at 18:14 |
| **Visual ID** | UNCERTAIN - Appears grey in V04, expected orange coat per legend |
| **Supporting Evidence** | Access log confirms entry; motive documented |
| **Exculpatory Evidence** | None definitive; statement contradicted by access log |

### Maya Reed
| Factor | Assessment |
|--------|------------|
| **Motive** | UNKNOWN - No documented need for prototype |
| **Opportunity** | HIGH - Entered via Service Door at 18:14 (D01) |
| **Alibi** | STRONG - Carrying cardboard box at 18:11 (V08), consistent with message D03 |
| **Visual ID** | UNCERTAIN - Appears grey in V04, expected purple coat per legend |
| **Supporting Evidence** | Cardboard box could have concealed/transported prototype |
| **Exculpatory Evidence** | Box at Loading Bay suggests legitimate activity; no motive documented |

### Nora Vale
| Factor | Assessment |
|--------|------------|
| **Motive** | UNKNOWN - No documented need for prototype |
| **Opportunity** | LOW - Seen in East Corridor only (V03) |
| **Alibi** | STRONG - Statement and camera footage consistent |
| **Visual ID** | CONFIRMED - Teal coat matches V03 |

### Theo Park
| Factor | Assessment |
|--------|------------|
| **Motive** | UNKNOWN - No documented need for prototype |
| **Opportunity** | LOW - Seen in Cafeteria (V06) |
| **Alibi** | STRONG - Statement and camera footage consistent |
| **Visual ID** | CONFIRMED - Blue coat matches V06 |

### Ada Finch
| Factor | Assessment |
|--------|------------|
| **Motive** | UNKNOWN - No documented need for prototype |
| **Opportunity** | LOW - Seen at Reception (V07) |
| **Alibi** | STRONG - Statement and camera footage consistent |
| **Visual ID** | CONFIRMED - Red coat matches V07 |

---

## 5. Key Deductions

1. **Service Corridor Vulnerability:** The floor plan (V01) and camera status (V10) confirm the Service Corridor is an unmonitored blind spot, enabling undetected access to the Lab.

2. **Disappearance Window:** Prototype visible at 18:00 (V02), missing by 18:18 (V05). Removal occurred within 8-minute window.

3. **Simultaneous Entry:** Access log (D01) shows Eli Stone and Maya Reed entered via SERVICE_DOOR at 18:14, coinciding with disappearance window.

4. **Motive Established:** Eli Stone's message (D03) establishes clear motive for needing prototype.

5. **Transport Method Plausible:** Maya Reed's cardboard box (V08, D02) could have concealed or transported the prototype.

6. **Alibis Confirmed:** Nora Vale, Theo Park, and Ada Finch all have corroborated alibis through camera footage matching their statements.

7. **Visual Identification Limitation:** V04 shows two grey figures; coat colors not distinguishable per D03 note that logs badge credentials, not biometric identity.

---

## 6. Contradictions

| Issue | Description | Explanation |
|-------|-------------|-------------|
| Coat Color Discrepancy | Access log shows Eli Stone (orange coat) and Maya Reed (purple coat). V04 shows two grey figures. | Camera rendering limitations or coat changes not documented; badge credentials logged but visual ID unreliable per D03 note |
| Statement vs Record | Eli claims he did not approach lab after 18:00 (D02). Access log shows entry at 18:14 (D01). | Service corridor is blind spot; Eli could have entered without being seen in East Corridor cameras |

---

## 7. Final Conclusion

**Most Likely Scenario:** The prototype was removed from the Lab between 18:00 and 18:18 via the unmonitored Service Corridor. Two individuals (Eli Stone and Maya Reed per access log D01) entered through the Service Door at 18:14, coinciding with the disappearance window. Eli Stone had documented motive for needing the prototype. Maya Reed was carrying a cardboard box that could have concealed or transported the prototype.

**Supporting Observations:**
- Service corridor provides unmonitored access (V01, V10)
- Prototype visible at 18:00, missing by 18:18 (V02, V05)
- Two people entered via Service Door at 18:14 (V04, D01)
- Eli Stone had documented motive (D03)
- Maya Reed's cardboard box could have been used for transport (V08, D02)

**Alternative Explanations:**
- Eli Stone alone entered and took prototype, with Maya Reed following later (but access log shows simultaneous entry)
- Maya Reed alone entered and took prototype (but Eli has documented motive)
- Third party used Service Door without badge credential logged (unlikely given D01 records)
- Prototype was moved but not removed - still in facility at different location

**Responsible Individual:** Cannot be definitively identified with current evidence. Both Eli Stone and Maya Reed entered together, making attribution uncertain.

---

## 8. Confidence and Limitations

**Confidence Level: 65%**

**Strengths:**
- Clear timeline established through camera footage
- Service corridor vulnerability documented
- Motive for Eli Stone confirmed
- Access log corroborates entry timing
- Alibis for other staff confirmed

**Limitations:**
- Coat color rendering in V04 prevents reliable visual identification of individuals
- No direct evidence showing who physically removed prototype from Lab
- Access log shows entry via Service Door but does not confirm destination (Lab vs elsewhere)
- Cardboard box contents not documented - could have been empty or contained prototype
- No surveillance footage of interior of Lab after 18:00 except V02 and V05
- Badge credentials logged but visual identification unreliable per D03 note

---

## 9. Recommended Next Investigative Steps

1. **Review badge credential logs** for Service Door to confirm if both Eli and Maya entered together or separately, and whether they had simultaneous access.

2. **Check Loading Bay records** to determine if cardboard box from V08 was later found with prototype or disposed of.

3. **Conduct separate interviews** with Eli Stone and Maya Reed about their movements after 18:14 and what occurred in the Lab.

4. **Search facility** for prototype in locations other than Lab, including service areas and storage.

5. **Review additional camera footage** that may have captured interior of Lab or Service Corridor during the incident window.

6. **Examine badge credential system** to determine if it can provide more detailed access information beyond simple entry/exit timestamps.

7. **Consider technical analysis** of cardboard box materials and contents if recovered.

---

*Report prepared: Investigation Case 03*
*Evidence exhibits referenced: V01-V10, D01-D03*
*Confidence level: 65%*
*Definitive attribution: Not possible with current evidence*