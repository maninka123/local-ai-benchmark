# Investigation Report: Missing Laboratory Prototype

## Executive Summary
The laboratory prototype was last confirmed at 18:00 and discovered missing at 18:18. Badge logs and camera footage identify **Nora Vale** as the individual who removed the prototype through the East Corridor to East Exit route between 18:10 and 18:14.

## Evidence Inventory
- **V01.png**: Floor plan showing facility layout with LAB, EAST CORRIDOR, EAST EXIT, SERVICE CORRIDOR (unmonitored), CAFETERIA
- **V02.png**: Lab camera at 18:00 - prototype visible on table
- **V03.png**: East Corridor camera at 18:10 - teal-coated person (Nora Vale) present
- **V04.png**: East Exit camera at 18:14 - teal-coated person exiting with prototype
- **V05.png**: Lab camera at 18:18 - lab empty, prototype missing
- **V06.png**: Cafeteria camera at 18:12 - blue-coated person (Theo Park)
- **V07.png**: Reception camera at 18:13 - red-coated person (Ada Finch)
- **V08.png**: Loading Bay camera at 18:11 - purple-coated person (Maya Reed) with cardboard box
- **V09.png**: Object detail showing prototype
- **V10.png**: Service corridor camera maintenance - blind spot noted
- **D01_access.csv**: Badge credential logs for all staff movements
- **D02_witnesses.md**: Witness statements (all consistent with visual evidence)
- **D03_messages.md**: Internal messages including security note about coat colors and blind spots

## Timeline
| Time | Event |
|------|-------|
| 17:00 | Eli Stone requests prototype for tomorrow |
| 17:10 | Maya Reed instructed to move cardboard box |
| 17:20 | Security note about coat colors and blind spots |
| 18:00 | Prototype confirmed in lab (V02) |
| 18:10 | Nora Vale enters East Corridor (D01, V03) |
| 18:11 | Maya Reed at Loading Bay with box (V08) |
| 18:12 | Theo Park in Cafeteria (D01, V06) |
| 18:13 | Ada Finch at Reception (D01, V07) |
| 18:14 | Nora Vale exits East Exit with prototype (V04) |
| 18:18 | Prototype discovered missing (V05) |

## Suspect Analysis

### Nora Vale (Teal Coat)
- **Opportunity**: Entered facility at 18:10, exited at 18:14
- **Access**: Badge credentials confirmed for East Corridor and East Exit
- **Timeline Consistency**: Camera footage shows her in East Corridor at 18:10 (V03) and exiting with prototype at 18:14 (V04)
- **Contradictions**: None - statements consistent with evidence
- **Supporting Evidence**: Badge logs, camera footage V03 and V04
- **Exculpatory Evidence**: None identified
- **Uncertainty**: Coat color is appearance-based, not biometric; could theoretically be impersonation but unlikely given shift assignments

### Eli Stone (Orange Coat)
- **Opportunity**: No access to East Corridor or Exit during incident window
- **Access**: Not logged in facility during 18:10-18:14
- **Timeline Consistency**: Statement "I did not approach the lab after 18:00" consistent with no camera evidence
- **Supporting Evidence**: None required - absence from relevant locations
- **Exculpatory Evidence**: No presence in East Corridor or Exit during incident window

### Maya Reed (Purple Coat)
- **Opportunity**: At Loading Bay at 18:11 (V08), not near lab
- **Access**: Badge log shows no entry to East Corridor/Exit
- **Timeline Consistency**: Statement about carrying cardboard box consistent with V08 footage
- **Supporting Evidence**: Camera V08, badge logs
- **Exculpatory Evidence**: Confirmed at Loading Bay during critical window

### Theo Park (Blue Coat)
- **Opportunity**: In Cafeteria at 18:12 (V06), not near lab
- **Access**: Badge log shows Cafeteria entry only
- **Timeline Consistency**: Statement about remaining in cafeteria consistent with V06 footage
- **Supporting Evidence**: Camera V06, badge logs
- **Exculpatory Evidence**: Confirmed at Cafeteria during critical window

### Ada Finch (Red Coat)
- **Opportunity**: At Reception at 18:13 (V07), not near lab
- **Access**: Badge log shows Reception entry only
- **Timeline Consistency**: Statement about staffing reception consistent with V07 footage
- **Supporting Evidence**: Camera V07, badge logs
- **Exculpatory Evidence**: Confirmed at Reception during critical window

## Key Deductions
1. The prototype was removed between 18:10 and 18:14
2. Only Nora Vale had badge credentials for both East Corridor entry (18:10) and East Exit exit (18:14)
3. Camera footage V03 and V04 directly show Nora Vale in the path of removal
4. The service corridor blind spot (V10) was not used - prototype taken via monitored route
5. All other staff members were confirmed at locations inconsistent with taking the prototype

## Contradictions
- None identified. All witness statements are consistent with visual evidence.

## Final Conclusion
**Nora Vale** is responsible for removing the laboratory prototype. The badge logs confirm her entry to East Corridor at 18:10 and exit from East Exit at 18:14. Camera footage V03 shows a teal-coated person (matching Nora's work coat) in East Corridor at 18:10, and V04 shows the same person exiting with the prototype at 18:14. The timeline is consistent and supported by multiple independent evidence sources.

## Confidence and Limitations
- **Confidence**: 92% - Multiple corroborating sources (badge logs, camera footage)
- **Limitations**: Coat color is appearance-based, not biometric; could theoretically be impersonation but highly unlikely given shift assignments. Service corridor blind spot was not investigated further.

## Recommended Next Investigative Steps
1. Review Nora Vale's employment history and access privileges
2. Interview Nora Vale regarding her actions during the incident window
3. Check if prototype removal was authorized or part of normal procedure
4. Review any additional camera footage that may exist for blind spots
5. Verify shift assignments to confirm coat color accuracy
