# Investigation Report: Missing Laboratory Prototype

## 1. Executive Summary
The prototype was last confirmed in the laboratory at 18:00 and discovered missing at 18:18. Analysis of access logs, camera footage, and witness statements reveals that **Eli Stone** removed the prototype through an unmonitored service corridor link at approximately 18:14 (real time). The service camera's +5 minute clock offset was critical to understanding the timeline.

## 2. Evidence Inventory
- **V01**: Floor plan showing facility layout and unmonitored service corridor link
- **V02**: Lab camera at 18:00 - prototype visible on table
- **V03**: East corridor camera at 18:10 - Nora Vale present
- **V04**: Service door camera at 18:19 (actual 18:14) - Eli Stone with prototype
- **V05**: Lab camera at 18:18 - prototype missing
- **V06**: Cafeteria camera at 18:12 - Theo Park present
- **V07**: Reception camera at 18:13 - Ada Finch present
- **V08**: Loading bay camera at 18:11 - Maya Reed with cardboard box
- **V09**: Object detail reference
- **V10**: Service camera maintenance note (+5 minute offset)
- **D01**: Access log showing entry times and doors
- **D02**: Witness statements (unverified)
- **D03**: Internal messages establishing context

## 3. Timeline
| Time | Event |
|------|-------|
| 17:00 | Eli requests prototype for tomorrow |
| 17:10 | Maya instructed to move cardboard box |
| 17:20 | Security note about camera offset |
| 18:00 | Prototype confirmed in lab (V02) |
| 18:10 | Nora Vale enters east corridor (D01, V03) |
| 18:11 | Maya at loading bay with box (V08) |
| 18:12 | Theo Park in cafeteria (D01, V06) |
| 18:13 | Ada Finch at reception (D01, V07) |
| 18:14 | Eli Stone enters service door (D01) - real time |
| 18:14+5=18:19 | Service camera shows Eli with prototype (V04) |
| 18:18 | Prototype missing from lab (V05) |

## 4. Suspect Analysis

### Eli Stone (Orange Coat)
- **Opportunity**: Entered service door at 18:14, used unmonitored link
- **Access**: Service door access confirmed in logs
- **Timeline consistency**: Camera footage matches corrected timestamp
- **Contradictions**: Claimed not to approach lab after 18:00 (false)
- **Supporting evidence**: V04 shows him with prototype at service door
- **Exculpatory evidence**: None found
- **Uncertainty**: Low - multiple corroborating sources

### Nora Vale (Teal Coat)
- **Opportunity**: Entered east corridor at 18:10
- **Access**: East corridor entry logged
- **Timeline consistency**: Present in east corridor, no lab access
- **Contradictions**: None
- **Supporting evidence**: V03 shows her in east corridor only
- **Exculpatory evidence**: Witness statement corroborated by camera

### Maya Reed (Purple Coat)
- **Opportunity**: At loading bay at 18:11 with cardboard box
- **Access**: Loading bay access confirmed
- **Timeline consistency**: Following instructions from 17:10 message
- **Contradictions**: None
- **Supporting evidence**: V08 shows her with cardboard box (not prototype)
- **Exculpatory evidence**: Witness statement about carrying supply box

### Theo Park (Blue Coat)
- **Opportunity**: In cafeteria from 18:12
- **Access**: Cafeteria entry logged
- **Timeline consistency**: Remained in cafeteria as stated
- **Contradictions**: None
- **Supporting evidence**: V06 shows him in cafeteria
- **Exculpatory evidence**: Witness statement corroborated by camera

### Ada Finch (Red Coat)
- **Opportunity**: At reception from 18:13
- **Access**: Reception entry logged
- **Timeline consistency**: Staffed reception as stated
- **Contradictions**: None
- **Supporting evidence**: V07 shows her at reception
- **Exculpatory evidence**: Witness statement corroborated by camera

## 5. Key Deductions
1. The service corridor provides an unmonitored access route to the lab (V01)
2. Service camera timestamp requires +5 minute correction (V10, D03)
3. Eli Stone entered through service door at 18:14 real time (D01, V04)
4. Prototype was removed between 18:14 and 18:18
5. Only Eli Stone had both opportunity and access to remove the prototype
6. Other staff members were in locations consistent with their statements

## 6. Contradictions
- **Eli Stone's statement**: "I did not approach the lab after 18:00" contradicted by V04 showing him at service door with prototype at 18:19 (actual 18:14)
- **Access log vs camera time**: D01 shows 18:14 entry, V04 shows 18:19 - resolved by V10's +5 minute offset note

## 7. Final Conclusion
**Eli Stone is responsible for the missing prototype.** He entered through the service door at 18:14 (real time), removed the prototype via the unmonitored link, and exited. The service camera's clock offset explains the apparent discrepancy between access log timestamps and camera footage.

## 8. Confidence and Limitations
- **Confidence**: 95%
- **Limitations**: 
  - Cannot determine exact time of removal (between 18:14-18:18)
  - No direct evidence of intent beyond opportunity
  - Service corridor surveillance may have gaps

## 9. Recommended Next Steps
1. Interview Eli Stone regarding his actions at 18:14
2. Review service corridor access logs for additional entries
3. Check if prototype was taken for legitimate project purposes
4. Verify whether unmonitored link should be secured or monitored
5. Review all camera footage between 18:00-18:20 for complete sequence
