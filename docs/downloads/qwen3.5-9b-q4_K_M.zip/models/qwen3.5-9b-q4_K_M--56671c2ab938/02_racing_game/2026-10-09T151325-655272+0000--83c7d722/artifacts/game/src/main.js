const carTypes = [
  { name: "Speedster", maxSpeed: 180, acceleration: 25, braking: 30, handling: 0.9, color: 0xff4444 },
  { name: "Steady", maxSpeed: 160, acceleration: 20, braking: 35, handling: 1.0, color: 0x44ff44 },
  { name: "Drifter", maxSpeed: 170, acceleration: 18, braking: 28, handling: 0.85, color: 0x4444ff }
];
const playerCar = {
  mesh: null,
  speed: 0,
  position: new THREE.Vector3(0, 0, 0),
  velocity: new THREE.Vector3(),
  steering: 0,
  lapTime: 0,
  checkpoints: [false, false, false, false, false],
  completedLaps: 0
};
const npcCars = [];
let selectedCarIndex = 0;
let cameraMode = 0; // 0: chase, 1: hood, 2: overhead
let gameState = "menu"; // menu, selecting, race, paused, results
let startTime = 0;
let lastTime = 0;
const keys = {};
const checkpointsOnTrack = [];
for (let i = 0; i < CONFIG.checkPoints; i++) {
  const angle = (i / CONFIG.checkPoints) * Math.PI * 2;
  const x = Math.cos(angle) * 140;
  const z = Math.sin(angle) * 140;
  checkpointsOnTrack.push({ x, z });
}
const trackPoints = [
  {x:0,y:0,z:0},
  {x:150,y:0,z:0},
  {x:200,y:80,z:0},
  {x:200,y:150,z:50},
  {x:120,y:180,z:100},
  {x:40,y:180,z:150},
  {x:-30,y:120,z:150},
  {x:-60,y:60,z:100},
  {x:-50,y:0,z:50},
  {x:-40,y:-80,z:0},
  {x:0,y:-120,z:0}
];
const trackCurve = new THREE.CatmullRomCurve3(trackPoints);
trackCurve.closed = true;
const roadWidth = CONFIG.trackWidth;
const barrierWidth = 2;
const barrierHeight = 1;
const numBarriers = 40;
for (let i = 0; i < numBarriers; i++) {
  const angle = (i / numBarriers) * Math.PI * 2;
  const x = Math.cos(angle) * 180;
  const z = Math.sin(angle) * 180;
  const barrierGeo = new THREE.BoxGeometry(barrierWidth, barrierHeight, barrierWidth);
  const barrierMat = new THREE.MeshStandardMaterial({ color: CONFIG.colors.barrier });
  const barrier = new THREE.Mesh(barrierGeo, barrierMat);
  barrier.position.set(x, barrierHeight/2, z);
  scene.add(barrier);
}
const roadGeo = new THREE.TubeGeometry(trackCurve, 100, roadWidth, 3, true);
const roadMat = new THREE.MeshStandardMaterial({ color: CONFIG.colors.road });
const road = new THREE.Mesh(roadGeo, roadMat);
scene.add(road);
const startLineGeo = new THREE.PlaneGeometry(roadWidth * 2, 5);
const startLineMat = new THREE.MeshBasicMaterial({ color: CONFIG.colors.startLine });
const startLine = new THREE.Mesh(startLineGeo, startLineMat);
startLine.rotation.x = -Math.PI / 2;
startLine.position.set(trackCurve.getPoint(0).x, 0.1, trackCurve.getPoint(0).z);
scene.add(startLine);

const finishLineGeo = new THREE.PlaneGeometry(roadWidth * 2, 5);
const finishLineMat = new THREE.MeshBasicMaterial({ color: CONFIG.colors.finishLine });
const finishLine = new THREE.Mesh(finishLineGeo, finishLineMat);
finishLine.rotation.x = -Math.PI / 2;
finishLine.position.set(trackCurve.getPoint(0).x, 0.1, trackCurve.getPoint(0).z);
scene.add(finishLine);

const cameraGroup = new THREE.Group();
scene.add(cameraGroup);
const playerCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
playerCamera.position.set(0, 2, -5);
const chaseCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
chaseCamera.position.set(0, 3, -8);
const overheadCamera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
overheadCamera.position.set(0, 50, 0);
overheadCamera.lookAt(0, 0, 0);
const cars = [
  { name: "Speedster", maxSpeed: 180, acceleration: 0.3, braking: 0.4, handling: 0.05, color: 0xff0000 },
  { name: "Steady", maxSpeed: 150, acceleration: 0.25, braking: 0.5, handling: 0.08, color: 0x00ff00 },
  { name: "Drifter", maxSpeed: 160, acceleration: 0.28, braking: 0.35, handling: 0.12, color: 0x0000ff }
];

const carGeometries = [
  new THREE.BoxGeometry(2, 1, 4),
  new THREE.BoxGeometry(2.2, 1.1, 4.2),
  new THREE.BoxGeometry(1.8, 0.9, 3.8)
];

const carMaterials = [
  new THREE.MeshStandardMaterial({ color: cars[0].color, roughness: 0.4 }),
  new THREE.MeshStandardMaterial({ color: cars[1].color, roughness: 0.5 }),
  new THREE.MeshStandardMaterial({ color: cars[2].color, roughness: 0.3 })
];

const playerCar = {
  mesh: null,
  config: null,
  position: { x: 0, y: 1, z: 0 },
  velocity: { x: 0, y: 0, z: 0 },
  speed: 0,
  steeringAngle: 0,
  lap: 0,
  checkpoints: [false, false, false, false, false],
  lastCheckpointIndex: -1
};
const npcCars = [];
for (let i = 0; i < CONFIG.npcCount; i++) {
  const offset = (i - CONFIG.npcCount/2) * 15;
  npcCars.push({
    mesh: null,
    config: cars[Math.floor(Math.random() * cars.length)],
    position: { x: trackCurve.getPoint(0).x + offset, y: 1, z: trackCurve.getPoint(0).z },
    velocity: { x: 0, y: 0, z: 0 },
    speed: 0,
    steeringAngle: 0,
    lap: 0,
    checkpoints: [false, false, false, false, false],
    lastCheckpointIndex: -1
  });
}

const keys = {};
window.addEventListener("keydown", (e) => { keys[e.code] = true; if(e.code === "KeyC") switchCamera(); if(e.code === "KeyP" || e.code === "Escape") togglePause(); if(e.code === "KeyR") restartRace(); });
window.addEventListener("keyup", (e) => { keys[e.code] = false; });

function switchCamera() {
  const cameras = [playerCamera, chaseCamera, overheadCamera];
  cameraGroup.position.copy(cameras[currentCameraIndex].position);
  cameraGroup.rotation.copy(cameras[currentCameraIndex].rotation);
  currentCameraIndex = (currentCameraIndex + 1) % cameras.length;
}

function togglePause() {
  isPaused = !isPaused;
  if (!isPaused) renderer.render(scene, camera);
}
const hud = {
  speed: document.getElementById("hud-speed"),
  lap: document.getElementById("hud-lap"),
  position: document.getElementById("hud-position"),
  timer: document.getElementById("hud-timer"),
  camera: document.getElementById("hud-camera"),
  pause: document.getElementById("hud-pause")
};

function updateHUD() {
  hud.speed.textContent = Math.round(playerCar.speed) + " km/h";
  hud.lap.textContent = "Lap " + (playerCar.lap + 1) + "/3";
  hud.position.textContent = "Position: " + getRacePosition();
  hud.timer.textContent = formatTime(gameTime);
  hud.camera.textContent = "Camera: " + cameraNames[currentCameraIndex];
  hud.pause.textContent = isPaused ? "PAUSED" : "";
}

function getRacePosition() {
  const positions = [playerCar, ...npcCars].map(c => c.lap * 1000 + getPositionAlongTrack(c.position));
  return Math.round(positions.indexOf(playerCar) + 1) + "/5";
}

function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return (m > 0 ? m + ":" : "") + String(s).padStart(2, "0");
}
const checkpointPositions = [];
for (let i = 0; i < CONFIG.checkPoints; i++) {
  const t = i / (CONFIG.checkPoints - 1);
  const point = trackCurve.getPointAt(t);
  checkpointPositions.push(point.clone());
}

function getPositionAlongTrack(position) {
  let minDist = Infinity;
  let closestIndex = 0;
  for (let i = 0; i < checkpointPositions.length; i++) {
    const dist = position.distanceTo(checkpointPositions[i]);
    if (dist < minDist) { minDist = dist; closestIndex = i; }
  }
  return closestIndex;
}

function checkCheckpoints(car) {
  const currentPos = getPositionAlongTrack(car.position);
  if (car.lastCheckpointIndex !== currentPos) {
    car.checkpoints[currentPos] = true;
    car.lastCheckpointIndex = currentPos;
  }
  return car.checkpoints.every(c => c);
}

function checkCollisions() {
  const allCars = [playerCar, ...npcCars];
  for (let i = 0; i < allCars.length; i++) {
    for (let j = i + 1; j < allCars.length; j++) {
      const carA = allCars[i];
      const carB = allCars[j];
      const dist = carA.position.distanceTo(carB.position);
      if (dist < 4) {
        const normal = new THREE.Vector3().subVectors(carB.position, carA.position).normalize();
        carA.velocity.x += normal.x * 2;
        carA.velocity.z += normal.z * 2;
        carB.velocity.x -= normal.x * 2;
        carB.velocity.z -= normal.z * 2;
      }
    }
  }
}
const keys = {};
window.addEventListener("keydown", (e) => { keys[e.code] = true; });
window.addEventListener("keyup", (e) => { keys[e.code] = false; });

function handleInput() {
  if (keys["ArrowUp"] || keys["KeyW"]) playerCar.velocity.y += 0.3;
  if (keys["ArrowDown"] || keys["KeyS"]) playerCar.velocity.y -= 0.3;
  if (keys["ArrowLeft"] || keys["KeyA"]) playerCar.velocity.x -= 0.2;
  if (keys["ArrowRight"] || keys["KeyD"]) playerCar.velocity.x += 0.2;
  
  const speed = Math.sqrt(playerCar.velocity.x**2 + playerCar.velocity.z**2);
  const maxSpeed = playerCar.maxSpeed * (playerCar.lap === 0 ? 0.5 : 1);
  if (speed > maxSpeed) {
    const ratio = maxSpeed / speed;
    playerCar.velocity.x *= ratio;
    playerCar.velocity.z *= ratio;
  }
}

function updateNPCs() {
  npcCars.forEach((npc, i) => {
    const targetPoint = trackCurve.getPointAt(npc.targetProgress);
    const direction = trackCurve.getTangentAt(npc.targetProgress).normalize();
    
    const distToTarget = npc.position.distanceTo(targetPoint);
    if (distToTarget < 10) {
      npc.velocity.x += direction.x * 0.2;
      npc.velocity.z += direction.z * 0.2;
      npc.targetProgress += 0.015;
      if (npc.targetProgress > 1) npc.targetProgress = 0;
    }
    
    const speed = Math.sqrt(npc.velocity.x**2 + npc.velocity.z**2);
    const maxSpeed = npc.maxSpeed * (npc.lap === 0 ? 0.5 : 1);
    if (speed < maxSpeed) {
      npc.velocity.x += direction.x * 0.05;
      npc.velocity.z += direction.z * 0.05;
    }
  });
}
const cameraNames = ["Chase", "Hood", "Overhead"];
let currentCameraIndex = 0;

function updateCamera() {
  const offset = new THREE.Vector3();
  if (currentCameraIndex === 0) { // Chase
    offset.set(0, 5, -12);
  } else if (currentCameraIndex === 1) { // Hood
    offset.set(0, 0.8, -2);
  } else { // Overhead
    offset.set(0, 40, -30);
  }
  const targetPos = playerCar.position.clone().add(offset).applyAxisAngle(new THREE.Vector3(0,1,0), playerCar.rotation.y);
  camera.position.lerp(targetPos, 0.1);
  camera.lookAt(playerCar.position);
}

function switchCamera() {
  currentCameraIndex = (currentCameraIndex + 1) % cameraNames.length;
  updateHUD();
}
const COLLISION_RADIUS = 1.5;
function checkCollisions() {
  const allCars = [playerCar, ...npcCars];
  for (let i = 0; i < allCars.length; i++) {
    for (let j = i + 1; j < allCars.length; j++) {
      const carA = allCars[i];
      const carB = allCars[j];
      const dist = carA.position.distanceTo(carB.position);
      if (dist < COLLISION_RADIUS * 2) {
        // Simple elastic collision response
        const normal = new THREE.Vector3().subVectors(carB.position, carA.position).normalize();
        const relativeVelocity = carA.velocity.clone().sub(carB.velocity);
        const separation = (COLLISION_RADIUS * 2 - dist) / 2;
        carA.velocity.add(normal.multiplyScalar(separation));
        carB.velocity.sub(normal.multiplyScalar(separation));
      }
    }
  }
}

function checkCheckpoints() {
  const checkpoints = [];
  for (let i = 0; i < CONFIG.checkPoints; i++) {
    const t = i / CONFIG.checkPoints;
    const point = trackCurve.getPointAt(t);
    checkpoints.push(point);
  }
  
  // Check player checkpoint
  let lastCheckpointIndex = -1;
  for (let i = 0; i < checkpoints.length; i++) {
    if (playerCar.position.distanceTo(checkpoints[i]) < 5) {
      lastCheckpointIndex = i;
    }
  }
  if (lastCheckpointIndex !== playerCar.lastCheckpointIndex && lastCheckpointIndex >= 0) {
    playerCar.lap++; // Completed a lap
    playerCar.lastCheckpointIndex = lastCheckpointIndex;
  }
  
  // Check NPCs
  npcCars.forEach(npc => {
    let lastCheckpointIndex = -1;
    for (let i = 0; i < checkpoints.length; i++) {
      if (npc.position.distanceTo(checkpoints[i]) < 5) {
        lastCheckpointIndex = i;
      }
    }
    if (lastCheckpointIndex !== npc.lastCheckpointIndex && lastCheckpointIndex >= 0) {
      npc.lap++;
      npc.lastCheckpointIndex = lastCheckpointIndex;
    }
  });
}
const hudElements = {
  speed: document.getElementById("speed"),
  lap: document.getElementById("lap"),
  position: document.getElementById("position"),
  camera: document.getElementById("camera"),
  timer: document.getElementById("timer")
};

function updateHUD() {
  hudElements.speed.textContent = Math.round(Math.sqrt(playerCar.velocity.x**2 + playerCar.velocity.z**2) * 36);
  hudElements.lap.textContent = `Lap ${playerCar.lap}/${CONFIG.numLaps}`;
  
  const positions = allCars.map((car, i) => ({ name: car.name, lap: car.lap }));
  positions.sort((a, b) => b.lap - a.lap);
  hudElements.position.textContent = `Position: ${positions.findIndex(p => p.name === "Player") + 1}`;
  
  hudElements.camera.textContent = cameraNames[currentCameraIndex];
  hudElements.timer.textContent = new Date().toLocaleTimeString();
}

function showMainMenu() {
  document.getElementById("mainMenu").style.display = "block";
  document.getElementById("gameContainer").style.display = "none";
  document.getElementById("resultsScreen").style.display = "none";
}

function showResults() {
  const positions = allCars.map((car, i) => ({ name: car.name, lap: car.lap }));
  positions.sort((a, b) => b.lap - a.lap);
  
  let html = "<h2>Race Results</h2><table>";
  positions.forEach((p, i) => {
    html += `<tr><td>${i+1}</td><td>${p.name}</td><td>Laps: ${p.lap}</td></tr>`;
  });
  html += "</table>";
  document.getElementById("resultsScreen").innerHTML = html;
  document.getElementById("resultsScreen").style.display = "block";
}

function startGame(selectedCar) {
  playerCar.type = selectedCar.type;
  playerCar.maxSpeed = selectedCar.maxSpeed;
  playerCar.acceleration = selectedCar.acceleration;
  playerCar.braking = selectedCar.braking;
  
  showMainMenu();
}
