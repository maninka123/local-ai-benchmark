FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\nemotron-3-nano-30b-a3b-q4_K_M--b725f1117407\03_detective\2026-10-12T123030-225292+0000--0f027e4f
