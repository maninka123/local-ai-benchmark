import * as THREE from 'three';
import { Track } from './track.js';
import { Car } from './car.js';
import { Input } from './input.js';
import { Race } from './race.js';
import { CameraController } from './camera.js';
import { UI } from './ui.js';
import { Physics } from './physics.js';

const canvas = document.querySelector('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb); // sky blue

// Lights
const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1.2);
hemi.position.set(0, 200, 0);
scene.add(hemi);
const dir = new THREE.DirectionalLight(0xffffff, 0.8);
dir.position.set(-100, 200, -100);
dir.castShadow = true;
scene.add(dir);

// Track
const track = new Track();
scene.add(track.mesh);

// Player car
const playerCar = new Car('Speedster', 0xff0000, {
  maxSpeed: 80,
  acceleration: 40,
  brakeDeceleration: 60,
  handling: 0.8,
  friction: 0.05,
});
playerCar.position.set(0, 0.75, -90);
scene.add(playerCar.mesh);

// NPC cars
const npcCars = [];
const npcParams = [
  { color: 0x00ff00, maxSpeed: 70, acceleration: 35, brakeDeceleration: 55, handling: 0.7, friction: 0.06 },
  { color: 0x0000ff, maxSpeed: 75, acceleration: 38, brakeDeceleration: 58, handling: 0.75, friction: 0.05 },
  { color: 0xffff00, maxSpeed: 65, acceleration: 32, brakeDeceleration: 52, handling: 0.6, friction: 0.07 },
  { color: 0xff00ff, maxSpeed: 78, acceleration: 39, brakeDeceleration: 59, handling: 0.78, friction: 0.05 },
];
for (let i = 0; i < 4; i++) {
  const car = new Car(`NPC${i+1}`, npcParams[i].color, npcParams[i]);
  car.position.set(0, 0.75, -90 + i * 5);
  scene.add(car.mesh);
  npcCars.push(car);
}

const input = new Input();
const race = new Race(playerCar, npcCars, track.waypoints);
const cameraController = new CameraController(camera, playerCar, scene);
const ui = new UI(race, playerCar, cameraController);
const physics = new Physics([playerCar, ...npcCars], track);

const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  const delta = clock.getDelta();
  input.update();
  race.update(delta, input);
  physics.update(delta);
  cameraController.update(delta);
  ui.update();
  renderer.render(scene, cameraController.camera);
}

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 20, -30);
camera.lookAt(0, 0, 0);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
