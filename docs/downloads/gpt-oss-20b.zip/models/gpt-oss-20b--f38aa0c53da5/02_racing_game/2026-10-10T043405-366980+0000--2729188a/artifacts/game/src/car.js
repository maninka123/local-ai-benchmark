// src/car.js
import * as THREE from 'three';

export class Car {
  constructor(name, color, params) {
    this.name = name;
    this.color = color;
    this.maxSpeed = params.maxSpeed || 50;
    this.acceleration = params.acceleration || 30;
    this.brakeDeceleration = params.brakeDeceleration || 40;
    this.handling = params.handling || 0.5; // steering sensitivity
    this.friction = params.friction || 0.1;

    this.position = new THREE.Vector3();
    this.velocity = new THREE.Vector3();
    this.direction = new THREE.Vector3(0, 0, 1); // forward
    this.rotation = 0; // yaw in radians

    this.mesh = this.createMesh();
    this.boundingBox = new THREE.Box3().setFromObject(this.mesh);
  }

  createMesh() {
    const geometry = new THREE.BoxGeometry(4, 1.5, 8);
    const material = new THREE.MeshStandardMaterial({ color: this.color });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    return mesh;
  }

  update(dt, input) {
    // input: { accelerate, brake, steer }
    // acceleration
    if (input.accelerate) {
      this.velocity.add(this.direction.clone().multiplyScalar(this.acceleration * dt));
    }
    if (input.brake) {
      this.velocity.add(this.direction.clone().multiplyScalar(-this.brakeDeceleration * dt));
    }
    // friction
    this.velocity.multiplyScalar(1 - this.friction * dt);
    // clamp speed
    const speed = this.velocity.length();
    if (speed > this.maxSpeed) {
      this.velocity.setLength(this.maxSpeed);
    }
    // steering
    const steerAmount = input.steer * this.handling * dt;
    this.rotation += steerAmount;
    this.direction.set(Math.sin(this.rotation), 0, Math.cos(this.rotation)).normalize();
    // move
    this.position.add(this.velocity.clone().multiplyScalar(dt));
    // update mesh
    this.mesh.position.copy(this.position);
    this.mesh.rotation.y = this.rotation;
    // update bounding box
    this.boundingBox.setFromObject(this.mesh);
  }
}
