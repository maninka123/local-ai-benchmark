// src/track.js
import * as THREE from 'three';

export const waypoints = [
  new THREE.Vector3(0, 0, 0),
  new THREE.Vector3(50, 0, 0),
  new THREE.Vector3(100, 0, 50),
  new THREE.Vector3(100, 0, 100),
  new THREE.Vector3(50, 0, 150),
  new THREE.Vector3(0, 0, 150),
  new THREE.Vector3(-50, 0, 100),
  new THREE.Vector3(-50, 0, 50),
  new THREE.Vector3(0, 0, 0),
];

export class Track {
  constructor() {
    this.mesh = this.createTrack();
  }

  createTrack() {
    const group = new THREE.Group();
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
    const road = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), roadMat);
    road.rotation.x = -Math.PI / 2;
    group.add(road);
    // boundaries
    const boundaryMat = new THREE.MeshStandardMaterial({ color: 0x222222 });
    const left = new THREE.Mesh(new THREE.BoxGeometry(2, 5, 200), boundaryMat);
    left.position.set(-100, 2.5, 0);
    group.add(left);
    const right = left.clone();
    right.position.set(100, 2.5, 0);
    group.add(right);
    const front = new THREE.Mesh(new THREE.BoxGeometry(200, 5, 2), boundaryMat);
    front.position.set(0, 2.5, -100);
    group.add(front);
    const back = front.clone();
    back.position.set(0, 2.5, 100);
    group.add(back);
    // start/finish line
    const line = new THREE.Mesh(new THREE.BoxGeometry(1, 0.1, 10), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    line.position.set(0, 0.05, -95);
    group.add(line);
    return group;
  }
}
