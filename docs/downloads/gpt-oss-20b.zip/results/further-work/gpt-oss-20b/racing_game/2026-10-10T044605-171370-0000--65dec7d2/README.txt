FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gpt-oss-20b--f38aa0c53da5\02_racing_game\2026-10-10T044605-171370+0000--65dec7d2
