FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gpt-oss-20b--f38aa0c53da5\03_detective\2026-10-10T045106-679823+0000--a1dddadf
