FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gpt-oss-20b--f38aa0c53da5\01_data_analysis\2026-10-10T044258-172207+0000--b863a69c
