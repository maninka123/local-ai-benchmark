FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\glm-4.7-flash-q4_K_M--96b29057eca0\03_detective\2026-10-12T114823-692361+0000--58ec7941
