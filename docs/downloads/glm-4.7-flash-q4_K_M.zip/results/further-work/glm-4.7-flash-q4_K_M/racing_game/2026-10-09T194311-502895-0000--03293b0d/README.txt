FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\glm-4.7-flash-q4_K_M--96b29057eca0\02_racing_game\2026-10-09T194311-502895+0000--03293b0d
