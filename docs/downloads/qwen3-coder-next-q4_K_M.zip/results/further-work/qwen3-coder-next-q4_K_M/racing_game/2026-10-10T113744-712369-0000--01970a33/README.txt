FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3-coder-next-q4_K_M--530048d6faa0\02_racing_game\2026-10-10T113744-712369+0000--01970a33
