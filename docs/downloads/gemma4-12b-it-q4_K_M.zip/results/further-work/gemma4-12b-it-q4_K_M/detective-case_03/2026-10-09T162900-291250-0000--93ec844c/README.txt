FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gemma4-12b-it-q4_K_M--6114515d63c1\03_detective\2026-10-09T162900-291250+0000--93ec844c
