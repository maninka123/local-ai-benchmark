FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gemma4-12b-it-q4_K_M--6114515d63c1\01_data_analysis\2026-10-09T160001-315989+0000--1f8e08cd
