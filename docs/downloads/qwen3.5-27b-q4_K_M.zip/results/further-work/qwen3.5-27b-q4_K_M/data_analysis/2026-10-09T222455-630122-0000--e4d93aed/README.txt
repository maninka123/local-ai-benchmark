FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3.5-27b-q4_K_M--64ae5b1d651f\01_data_analysis\2026-10-09T222455-630122+0000--e4d93aed
