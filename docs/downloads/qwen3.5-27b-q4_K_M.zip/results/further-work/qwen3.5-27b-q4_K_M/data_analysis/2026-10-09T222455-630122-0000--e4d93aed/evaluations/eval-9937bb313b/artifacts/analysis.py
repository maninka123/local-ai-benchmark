"""
Company Performance Analysis Script
====================================
This script performs comprehensive analysis of company operational and financial data.
It loads 6 datasets, cleans them, calculates metrics, generates findings and visualizations.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from datetime import datetime

# Set random seed for reproducibility
np.random.seed(42)

# Create output directories
os.makedirs('/output/figures', exist_ok=True)

# ============================================================================
# SECTION 1: DATA LOADING
# ============================================================================

print("=" * 60)
print("LOADING DATASETS")
print("=" * 60)

input_dir = '/input'
output_dir = '/output'

# Load all datasets
transactions = pd.read_csv(os.path.join(input_dir, 'transactions.csv'))
products = pd.read_csv(os.path.join(input_dir, 'products.csv'))
customers = pd.read_csv(os.path.join(input_dir, 'customers.csv'))
regions = pd.read_csv(os.path.join(input_dir, 'regions.csv'))
inventory = pd.read_csv(os.path.join(input_dir, 'inventory.csv'))
events = pd.read_csv(os.path.join(input_dir, 'operational_events.csv'))

print(f"\nTransactions: {transactions.shape}")
print(f"Products: {products.shape}")
print(f"Customers: {customers.shape}")
print(f"Regions: {regions.shape}")
print(f"Inventory: {inventory.shape}")
print(f"Events: {events.shape}")

# ============================================================================
# SECTION 2: DATA QUALITY ASSESSMENT
# ============================================================================

print("\n" + "=" * 60)
print("DATA QUALITY ASSESSMENT")
print("=" * 60)

# Track data quality issues
data_quality = {
    'raw_transactions': len(transactions),
    'duplicate_transaction_ids': transactions.duplicated(subset=['transaction_id']).sum(),
    'missing_unit_cost': transactions['unit_cost'].isnull().sum(),
    'invalid_quantity': (transactions['quantity'] <= 0).sum(),
    'invalid_revenue': (transactions['revenue'] <= 0).sum(),
    'invalid_selling_price': (transactions['selling_price'] <= 0).sum(),
    'invalid_discount': ((transactions['discount'] < 0) | (transactions['discount'] > 1)).sum()
}

print(f"\nDuplicate transaction_ids: {data_quality['duplicate_transaction_ids']}")
print(f"Missing unit_cost values: {data_quality['missing_unit_cost']}")
print(f"Invalid quantity (<=0): {data_quality['invalid_quantity']}")
print(f"Invalid revenue (<=0): {data_quality['invalid_revenue']}")
print(f"Invalid selling_price (<=0): {data_quality['invalid_selling_price']}")
print(f"Invalid discount (<0 or >1): {data_quality['invalid_discount']}")

# ============================================================================
# SECTION 3: DATA CLEANING
# ============================================================================

print("\n" + "=" * 60)
print("DATA CLEANING")
print("=" * 60)

# Start with raw transactions
df = transactions.copy()
initial_count = len(df)

# Step 1: Remove duplicate transaction_ids
df = df.drop_duplicates(subset=['transaction_id'], keep='first')
removed_dups = initial_count - len(df)
print(f"After removing {removed_dups} duplicates: {len(df)} rows")

# Step 2: Filter invalid quantities (must be positive)
df = df[df['quantity'] > 0]
removed_qty = (initial_count - removed_dups) - len(df)
print(f"After removing {removed_qty} invalid quantity records: {len(df)} rows")

# Step 3: Filter missing/invalid unit_cost (must be positive)
df = df[df['unit_cost'] > 0]
removed_cost = (initial_count - removed_dups) - len(df)
print(f"After removing {removed_cost} invalid unit_cost records: {len(df)} rows")

# Step 4: Filter invalid revenue (must be positive)
df = df[df['revenue'] > 0]
removed_rev = (initial_count - removed_dups) - len(df)
print(f"After removing {removed_rev} invalid revenue records: {len(df)} rows")

# Step 5: Filter invalid selling_price (must be positive)
df = df[df['selling_price'] > 0]
removed_price = (initial_count - removed_dups) - len(df)
print(f"After removing {removed_price} invalid selling_price records: {len(df)} rows")

# Step 6: Filter invalid discount (must be between 0 and 1)
df = df[(df['discount'] >= 0) & (df['discount'] <= 1)]
removed_disc = (initial_count - removed_dups) - len(df)
print(f"After removing {removed_disc} invalid discount records: {len(df)} rows")

# Save cleaned data
df.to_csv(os.path.join(output_dir, 'cleaned_transactions.csv'), index=False)
print(f"\nCleaned transactions saved to /output/cleaned_transactions.csv")
