FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3.5-27b-q4_K_M--64ae5b1d651f\02_racing_game\2026-10-09T232307-428711+0000--afd55c4d
