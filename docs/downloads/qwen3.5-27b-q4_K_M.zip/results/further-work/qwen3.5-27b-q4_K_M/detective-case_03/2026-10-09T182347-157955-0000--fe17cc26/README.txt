FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3.5-27b-q4_K_M--64ae5b1d651f\03_detective\2026-10-09T182347-157955+0000--fe17cc26
