import * as THREE from 'three';

// ============================================
// GAME CONSTANTS AND CONFIGURATION
// ============================================
const CAR_STATS = {
  speedster: { name: "Speedster", maxSpeed: 280, acceleration: 0.8, braking: 0.9, handling: 0.85, color: 0xe94560 },
  cruiser: { name: "Cruiser", maxSpeed: 240, acceleration: 0.6, braking: 0.75, handling: 0.9, color: 0x4ecdc4 },
  beast: { name: "Beast", maxSpeed: 300, acceleration: 0.5, braking: 0.85, handling: 0.7, color: 0xff6b6b }
};

const TRACK_WIDTH = 12;
const NUM_LAPS = 3;
const NUM_NPCS = 4;

// Utility functions
function lerp(a, b, t) { return a + (b - a) * t; }
function clamp(val, min, max) { return Math.max(min, Math.min(max, val)); }
function distance2D(p1, p2) {
  const dx = p1.x - p2.x;
  const dz = p1.z - p2.z;
  return Math.sqrt(dx * dx + dz * dz);
}

// ============================================
// TRACK CLASS
// ============================================
class Track {
  constructor() {
    this.waypoints = [];
    this.checkpoints = [];
    this.generateTrack();
  }

  generateTrack() {
    const points = [
      { x: 0, z: -150 },   // Start/Finish line
      { x: 80, z: -120 },  // Corner 1
      { x: 150, z: -50 },  // Straight east
      { x: 180, z: 30 },   // Corner 2
      { x: 150, z: 120 },  // North straight
      { x: 80, z: 150 },   // Corner 3
      { x: -50, z: 150 },  // West straight
      { x: -120, z: 120 }, // Corner 4
      { x: -150, z: 50 },  // South-west
      { x: -180, z: -30 }, // Corner 5
      { x: -150, z: -100 },// Back to start area
      { x: -80, z: -130 }, // Final approach
    ];

    const segments = [];
    for (let i = 0; i < points.length; i++) {
      const p1 = points[i];
      const p2 = points[(i + 1) % points.length];
      const numPoints = Math.ceil(distance2D(p1, p2) / 5);
      for (let j = 0; j < numPoints; j++) {
        const t = j / numPoints;
        segments.push({ x: lerp(p1.x, p2.x, t), z: lerp(p1.z, p2.z, t) });
      }
    }
    this.waypoints = segments;

    // Add checkpoints
    for (let i = 0; i < segments.length; i += 8) {
      this.checkpoints.push({
        position: new THREE.Vector3(segments[i].x, 0.5, segments[i].z),
        radius: 15
      });
    }
  }

  getNearestWaypoint(position) {
    let minDist = Infinity;
    let nearestIndex = 0;
    for (let i = 0; i < this.waypoints.length; i++) {
      const wp = this.waypoints[i];
      const dist = Math.sqrt((wp.x - position.x)**2 + (wp.z - position.z)**2);
      if (dist < minDist) { minDist = dist; nearestIndex = i; }
    }
    return { index: nearestIndex, waypoint: this.waypoints[nearestIndex], distance: minDist };
  }
}
class Car {
  constructor(scene, stats, isPlayer = false, startOffset = 0) {
