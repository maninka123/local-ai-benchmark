FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3.6-35b-a3b-q4_K_M--b52ca43760e9\03_detective\2026-10-09T204334-869643+0000--33c41999
