FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\qwen3-vl-30b-a3b-instruct--c871fc73fabc\02_racing_game\2026-10-10T142751-670489+0000--c5f0d666
