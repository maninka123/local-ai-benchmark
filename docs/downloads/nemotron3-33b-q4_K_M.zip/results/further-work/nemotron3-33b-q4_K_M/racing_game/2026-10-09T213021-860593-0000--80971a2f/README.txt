FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\nemotron3-33b-q4_K_M--767c4367ff03\02_racing_game\2026-10-09T213021-860593+0000--80971a2f
