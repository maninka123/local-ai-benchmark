FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gemma4-26b-a4b-it-q4_K_M--58820a4a8087\03_detective\2026-10-09T192733-566795+0000--084c1c95
