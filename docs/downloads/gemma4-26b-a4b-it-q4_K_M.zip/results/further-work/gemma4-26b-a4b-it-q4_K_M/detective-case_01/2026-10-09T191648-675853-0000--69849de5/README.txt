FURTHER WORK
All prompts update artifacts/ in this one workspace.
Prompt history, cumulative time and tokens are in revision.json.
Initial results remain at: .\models\gemma4-26b-a4b-it-q4_K_M--58820a4a8087\03_detective\2026-10-09T191648-675853+0000--69849de5
